/*
 * \brief Receive data from wireless remote controller (implementation)
 *
 * \author Quentin Comte-Gaz <quentin@comte-gaz.com>
 * \date 1 July 2016
 * \license MIT License (contact me if too restrictive)
 * \copyright Copyright (c) 2016 Quentin Comte-Gaz
 * \version 1.0
 */

#include "WirelessRemoteController.h"

void FromByte(uint8_t c, bool b[6])
{
    for (int i=0; i < 6; ++i)
        b[i] = (c & (1<<i)) != 0;
 //return b;
}
WirelessRemoteController::WirelessRemoteController(bool transmitter,uint8_t pin_D0, uint8_t pin_D1, uint8_t pin_D2, uint8_t pin_D3)
{
  _pins[0] = pin_D0;
  _pins[1] = pin_D1;
  _pins[2] = pin_D2;
  _pins[3] = pin_D3;
  //_pins[6] = pin_TE;
  if(transmitter==false){
  for (int i = 0; i < 4; i++) {
    pinMode(_pins[i], INPUT);
	digitalWrite(_pins[i],LOW);
  }
  pinMode(PA8, INPUT); 
  }
  else{
	for (int i = 0; i < 4; i++) {
    pinMode(_pins[i],OUTPUT_OPEN_DRAIN);
	
  }
  pinMode(PA8,OUTPUT_OPEN_DRAIN);
  digitalWrite(PA8,LOW);
  }
}

uint8_t WirelessRemoteController::getCurrentValue()
{
  detachInterrupt(PA8);

  digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
  bool pino=0;
  uint8_t sayac;
  uint8_t gelen1=0x00;uint8_t gelen2=0x01;
  while((gelen1^gelen2!=0x00) && sayac<3){
  for (int i = 0; i < 4; i++) {
    pino=digitalRead(_pins[i]);
	if(pino==HIGH){	gelen1|=(1<<i); }
    
  }  
  gelen1=(~gelen1&0x0F);
  
   uint8_t gelen2=0x00;
  for (int i = 0; i < 4; i++) {
    pino=digitalRead(_pins[i]);
	if(pino==HIGH){	gelen2|=(1<<i); }
    
  }  
  gelen2=(~gelen2&0x0F);
  //if(gelen>0x0F){gelen=0x00;}
  sayac++;
  }
  return gelen2;
  remote_controller.addTrigger(PA8,extern receiveFromRemoteController);
}

void WirelessRemoteController::sendCurrentValue(uint8_t datam)
{ 
  
  digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
  bool pinok=0;
  for (int i = 0; i < 4; i++) {
	pinok=datam&(1<<i); 
    if(pinok){ digitalWrite(_pins[i],LOW);}
	if(!pinok){ digitalWrite(_pins[i],HIGH);}
    //is_valid |= pinok;
  }
  //digitalWrite(PA8,LOW);
  delay(100);
 // digitalWrite(PA8,HIGH);
}

void WirelessRemoteController::addTrigger(uint8 pin_DT, void (*function)())
{
  attachInterrupt(digitalPinToInterrupt(pin_DT), function, RISING);
}