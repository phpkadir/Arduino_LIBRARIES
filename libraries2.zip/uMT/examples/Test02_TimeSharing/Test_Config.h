
// Demo configuration

#define TEST_TIMESHARING			1		// Test self Yield()

/////////// EOF