
// Demo configuration

#define TEST_TASK_DELETE			1		// 

/////////// EOF