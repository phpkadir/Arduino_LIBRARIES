
// Demo configuration

#define TEST_TASK_BADEXIT			1 

/////////// EOF