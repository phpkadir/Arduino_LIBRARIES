
// Demo configuration

#define TEST_SEMAPHORES			1 

/////////// EOF