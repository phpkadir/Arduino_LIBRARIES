
// Demo configuration

#define TEST_EVENTS			1 

/////////// EOF